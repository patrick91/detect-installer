__version__ = "1.1.0"

def main() -> None:
    print(__version__)
